This is the initial landing page for your workshop. Include in this page a description of what your workshop is about.
